<?php

namespace App\DataFixtures;

use App\Entity\User;
use App\Entity\Article;
use App\Entity\Address;
use App\Entity\Category;
use App\Entity\Credentials;
use App\Entity\Order;
use App\Entity\Cart;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        // $faker = Faker\Factory::create('fr_FR');
        // $faker = Faker\Factory::create();
        // $users = [];
        // $NUsers = 50;

        // for ($i = 0; $i <= $NUsers - 1; $i++) {
        //     $user = new User();
        //     $user->setFirstName($faker->firstName());
        //     $user->setLastName($faker->lastName());
        //     $user->setPhone($faker->phoneNumber());
        //     $user->setRole("visiteur");
        //     $manager->persist($user);
        //     $users[] = $user;
        // }

        // $articles = [];
        // $NArticles = 200;

        // for ($i = 0; $i <= $NArticles - 1; $i++) {
        //     $articleStockQuantity = rand(0, 100);
        //     $boughtPrice = rand(0, 50);
        //     $sellPriceHT = rand(12, 22) / 10 * $boughtPrice;
        //     $tva = rand(0, 25) / 10;
        //     $sellPriceTTC = (1 + $tva / 100) * $sellPriceHT;

        //     $article = new Article();
        //     $article->setArticleRef($faker->randomLetter());
        //     $article->setArticleName($faker->word());
        //     $article->setArticleImages($faker->imageUrl());
        //     $article->setArticleThumbNaill($faker->imageUrl());
        //     $article->setArticleStockQuantity($articleStockQuantity);
        //     $article->setDescription($faker->text());
        //     $article->setBoughtPrice($boughtPrice);
        //     $article->setSellPriceHT($sellPriceHT);
        //     $article->setSellPriceTTC($sellPriceTTC);
        //     $article->setTVA($tva);
        //     $article->setDetails($faker->text());

        //     $manager->persist($article);
        //     $articles[] = $article;
        // }

        // $addresses = [];
        // $NAddresses = $NUsers;

        // for ($i = 0; $i <= $NAddresses - 1; $i++) {
        //     $address = new Address();
        //     $address->setStreetName($faker->streetName());
        //     $address->setStreetNumber($faker->buildingNumber());
        //     $address->setCity($faker->city());
        //     $address->setCountry($faker->country());
        //     $address->setZIPCode($faker->postcode());
        //     $address->setUser($users[$i]);
        //     $manager->persist($address);
        //     $addresses[] = $address;
        // }

        // $categories = [];
        // $NCategories = 3;

        // for ($i = 0; $i <= $NCategories - 1; $i++) {
        //     $category = new Category();
        //     $category->setNameCategory($faker->word);
        //     $manager->persist($category);
        //     $categories[] = $category;
        // }

        // $credentialses = [];
        // $NCredentialses = $NUsers;

        // for ($i = 0; $i <= $NCredentialses - 1; $i++) {
        //     $credentials = new Credentials();
        //     $credentials->setUserName($faker->userName());
        //     $credentials->setUserEmail($faker->email());
        //     $credentials->setPassword($faker->password());
        //     $credentials->setUser($users[$i]);
        //     $manager->persist($credentials);
        //     $credentialses[] = $credentials;
        // }

        // $orders = [];
        // $NOrders = 100;

        // for ($i = 0; $i <= $NOrders - 1; $i++) {
        //     $order = new Order();
        //     $order->setOrderDate($faker->dateTime());
        //     $order->setDelivered(rand(0, 1));
        //     $order->setPaid(rand(0, 1));
        //     $order->setDeliveryDate($faker->dateTime());
        //     $order->setDeliveryInfo($faker->text());
        //     $order->setStatus($faker->word);
        //     $order->setUser($users[$i]);
        //     $manager->persist($order);
        //     $orders[] = $order;
        // }

        // $cartArticles = [];
        // $NCartArticles = 10;

        // for ($i = 0; $i <= $NCartArticles - 1; $i++) {
        //     $articleQuantity = rand(1, 9);
        //     $cartArticle = new Cart();
        //     $cartArticle->setArticleQuantity($articleQuantity);
        //     $manager->persist($cartArticle);
        //     $cartArticles[] = $cartArticle;
        // }

        // $manager->flush();
    }
}
