<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\UserType;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Authentication\Token\NullToken;

#[Route('user')]
class UserController extends AbstractController
{
    // #[Route('/add/{fn}/{ln}/{ph}/{r}', name: 'addUser')]
    // public function add($fn, $ln, $ph, $r, ManagerRegistry $doctrine): RedirectResponse
    // {
    //     $manager = $doctrine->getManager();
    //     $user = new User();
    //     $user->setFirstName($fn);
    //     $user->setLastName($ln);
    //     $user->setPhone($ph);
    //     $user->setRole($r);
    //     $manager->persist($user);
    //     $manager->flush();
    //     //return $this->render('user/add.html.twig', ['user' => $user]);
    //     return $this->redirectToRoute('readUser');
    // }

    #[Route('/edit/{id?0}', name: 'editUser')]
    public function add(User $user = null, ManagerRegistry $doctrine, Request $request): Response
    {
        if (!$user) {
            $user = new User();
        }

        $form = $this->createForm(UserType::class, $user);
        // $form->remove("FirstName");
        $form->handleRequest($request);

        if ($form->isSubmitted()) {
            $manager = $doctrine->getManager();
            $manager->persist($user);
            $manager->flush();
            return $this->redirectToRoute('readUser');
        } else {
            return $this->render('user/add.html.twig', ['form' => $form->createView()]);
        }
    }

    #[Route('/read', name: 'readUser')]
    public function table(ManagerRegistry $doctrine): Response
    {
        $repository = $doctrine->getRepository(User::class);
        $users = $repository->findAll();
        return $this->render('user/index.html.twig', ['users' => $users]);
    }

    #[Route('/update/{id}/{fn}/{ln}/{ph}/{r}', name: 'updateUser')]
    public function update(User $user = null, $fn, $ln, $ph, $r, ManagerRegistry $doctrine): RedirectResponse
    {
        if ($user) {
            $manager = $doctrine->getManager();
            $user->setFirstName($fn);
            $user->setLastName($ln);
            $user->setPhone($ph);
            $user->setRole($r);
            $manager->persist($user);
            $manager->flush();

            return $this->redirectToRoute('readUser');
        }
    }

    #[Route('/delete/{id?0}', name: 'deleteUser')]
    public function del(User $user = null, ManagerRegistry $doctrine): RedirectResponse
    {
        $manager = $doctrine->getManager();
        $manager->remove($user);
        $manager->flush();
        return $this->redirectToRoute('readUser');
    }
}
