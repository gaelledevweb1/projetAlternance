<?php

namespace App\Controller;

use App\Entity\Address;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('address')]
class AddressController extends AbstractController
{
    #[Route('/read', name: 'readAddress')]
    public function table(ManagerRegistry $doctrine): Response
    {
        $repository = $doctrine->getRepository(Address::class);
        $addresses = $repository->findAll();
        return $this->render('address/index.html.twig', ['addresses' => $addresses]);
    }
}
