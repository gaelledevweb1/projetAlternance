<?php

namespace App\Entity;

use App\Repository\OrderRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: OrderRepository::class)]
#[ORM\Table(name: '`order`')]
class Order
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $OrderDate = null;

    #[ORM\Column]
    private ?bool $Paid = null;

    #[ORM\Column]
    private ?bool $Delivered = null;

    #[ORM\Column(length: 255)]
    private ?string $Status = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $DeliveryDate = null;

    #[ORM\Column(length: 255)]
    private ?string $DeliveryInfo = null;

    #[ORM\ManyToOne(inversedBy: 'orders')]
    private ?User $User = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Address $Address = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Cart $Cart = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getOrderDate(): ?\DateTimeInterface
    {
        return $this->OrderDate;
    }

    public function setOrderDate(\DateTimeInterface $OrderDate): static
    {
        $this->OrderDate = $OrderDate;

        return $this;
    }

    public function isPaid(): ?bool
    {
        return $this->Paid;
    }

    public function setPaid(bool $Paid): static
    {
        $this->Paid = $Paid;

        return $this;
    }

    public function isDelivered(): ?bool
    {
        return $this->Delivered;
    }

    public function setDelivered(bool $Delivered): static
    {
        $this->Delivered = $Delivered;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->Status;
    }

    public function setStatus(string $Status): static
    {
        $this->Status = $Status;

        return $this;
    }

    public function getDeliveryDate(): ?\DateTimeInterface
    {
        return $this->DeliveryDate;
    }

    public function setDeliveryDate(\DateTimeInterface $DeliveryDate): static
    {
        $this->DeliveryDate = $DeliveryDate;

        return $this;
    }

    public function getDeliveryInfo(): ?string
    {
        return $this->DeliveryInfo;
    }

    public function setDeliveryInfo(string $DeliveryInfo): static
    {
        $this->DeliveryInfo = $DeliveryInfo;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->User;
    }

    public function setUser(?User $User): static
    {
        $this->User = $User;

        return $this;
    }

    public function getAddress(): ?Address
    {
        return $this->Address;
    }

    public function setAddress(?Address $Address): static
    {
        $this->Address = $Address;

        return $this;
    }

    public function getCart(): ?Cart
    {
        return $this->Cart;
    }

    public function setCart(?Cart $Cart): static
    {
        $this->Cart = $Cart;

        return $this;
    }
}
