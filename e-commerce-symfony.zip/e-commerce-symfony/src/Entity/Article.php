<?php

namespace App\Entity;

use App\Repository\ArticleRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ArticleRepository::class)]
class Article
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $ArticleRef = null;

    #[ORM\Column(length: 255)]
    private ?string $ArticleName = null;

    #[ORM\Column(length: 255)]
    private ?string $ArticleImages = null;

    #[ORM\Column(length: 255)]
    private ?string $ArticleThumbnaill = null;

    #[ORM\Column]
    private ?int $ArticleStockQuantity = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $Description = null;

    #[ORM\Column]
    private ?float $BoughtPrice = null;

    #[ORM\Column]
    private ?float $SellPriceHT = null;

    #[ORM\Column]
    private ?float $SellPriceTTC = null;

    #[ORM\Column]
    private ?float $TVA = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $Details = null;

    #[ORM\ManyToOne(inversedBy: 'articles')]
    private ?Category $Category = null;

    #[ORM\ManyToOne(inversedBy: 'Article')]
    private ?Cart $cart = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getArticleRef(): ?string
    {
        return $this->ArticleRef;
    }

    public function setArticleRef(string $ArticleRef): static
    {
        $this->ArticleRef = $ArticleRef;

        return $this;
    }

    public function getArticleName(): ?string
    {
        return $this->ArticleName;
    }

    public function setArticleName(string $ArticleName): static
    {
        $this->ArticleName = $ArticleName;

        return $this;
    }

    public function getArticleImages(): ?string
    {
        return $this->ArticleImages;
    }

    public function setArticleImages(string $ArticleImages): static
    {
        $this->ArticleImages = $ArticleImages;

        return $this;
    }

    public function getArticleThumbnaill(): ?string
    {
        return $this->ArticleThumbnaill;
    }

    public function setArticleThumbnaill(string $ArticleThumbnaill): static
    {
        $this->ArticleThumbnaill = $ArticleThumbnaill;

        return $this;
    }

    public function getArticleStockQuantity(): ?int
    {
        return $this->ArticleStockQuantity;
    }

    public function setArticleStockQuantity(int $ArticleStockQuantity): static
    {
        $this->ArticleStockQuantity = $ArticleStockQuantity;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->Description;
    }

    public function setDescription(?string $Description): static
    {
        $this->Description = $Description;

        return $this;
    }

    public function getBoughtPrice(): ?float
    {
        return $this->BoughtPrice;
    }

    public function setBoughtPrice(float $BoughtPrice): static
    {
        $this->BoughtPrice = $BoughtPrice;

        return $this;
    }

    public function getSellPriceHT(): ?float
    {
        return $this->SellPriceHT;
    }

    public function setSellPriceHT(float $SellPriceHT): static
    {
        $this->SellPriceHT = $SellPriceHT;

        return $this;
    }

    public function getSellPriceTTC(): ?float
    {
        return $this->SellPriceTTC;
    }

    public function setSellPriceTTC(float $SellPriceTTC): static
    {
        $this->SellPriceTTC = $SellPriceTTC;

        return $this;
    }

    public function getTVA(): ?float
    {
        return $this->TVA;
    }

    public function setTVA(float $TVA): static
    {
        $this->TVA = $TVA;

        return $this;
    }

    public function getDetails(): ?string
    {
        return $this->Details;
    }

    public function setDetails(?string $Details): static
    {
        $this->Details = $Details;

        return $this;
    }

    public function getCategories(): ?Category
    {
        return $this->Category;
    }

    public function setCategories(?Category $Category): static
    {
        $this->Category = $Category;

        return $this;
    }

    public function getCart(): ?Cart
    {
        return $this->cart;
    }

    public function setCart(?Cart $cart): static
    {
        $this->cart = $cart;

        return $this;
    }
}
