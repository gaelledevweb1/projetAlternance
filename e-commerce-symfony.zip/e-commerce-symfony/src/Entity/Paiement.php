<?php

namespace App\Entity;

use App\Repository\PaiementRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PaiementRepository::class)]
class Paiement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $BankName = null;

    #[ORM\Column(length: 255)]
    private ?string $CardName = null;

    #[ORM\Column(length: 255)]
    private ?string $CardNumber = null;

    #[ORM\Column(length: 255)]
    private ?string $CardNetwork = null;

    #[ORM\Column(length: 255)]
    private ?string $CardHolderName = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $ExpirationDate = null;

    #[ORM\Column(length: 255)]
    private ?string $CVCCode = null;

    #[ORM\Column(length: 255)]
    private ?string $SecurityCode = null;

    #[ORM\Column(length: 255)]
    private ?string $Currency = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?User $User = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?Cart $Cart = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getBankName(): ?string
    {
        return $this->BankName;
    }

    public function setBankName(string $BankName): static
    {
        $this->BankName = $BankName;

        return $this;
    }

    public function getCardName(): ?string
    {
        return $this->CardName;
    }

    public function setCardName(string $CardName): static
    {
        $this->CardName = $CardName;

        return $this;
    }

    public function getCardNumber(): ?string
    {
        return $this->CardNumber;
    }

    public function setCardNumber(string $CardNumber): static
    {
        $this->CardNumber = $CardNumber;

        return $this;
    }

    public function getCardNetwork(): ?string
    {
        return $this->CardNetwork;
    }

    public function setCardNetwork(string $CardNetwork): static
    {
        $this->CardNetwork = $CardNetwork;

        return $this;
    }

    public function getCardHolderName(): ?string
    {
        return $this->CardHolderName;
    }

    public function setCardHolderName(string $CardHolderName): static
    {
        $this->CardHolderName = $CardHolderName;

        return $this;
    }

    public function getExpirationDate(): ?\DateTimeInterface
    {
        return $this->ExpirationDate;
    }

    public function setExpirationDate(\DateTimeInterface $ExpirationDate): static
    {
        $this->ExpirationDate = $ExpirationDate;

        return $this;
    }

    public function getCVCCode(): ?string
    {
        return $this->CVCCode;
    }

    public function setCVCCode(string $CVCCode): static
    {
        $this->CVCCode = $CVCCode;

        return $this;
    }

    public function getSecurityCode(): ?string
    {
        return $this->SecurityCode;
    }

    public function setSecurityCode(string $SecurityCode): static
    {
        $this->SecurityCode = $SecurityCode;

        return $this;
    }

    public function getCurrency(): ?string
    {
        return $this->Currency;
    }

    public function setCurrency(string $Currency): static
    {
        $this->Currency = $Currency;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->User;
    }

    public function setUser(?User $User): static
    {
        $this->User = $User;

        return $this;
    }

    public function getCart(): ?Cart
    {
        return $this->Cart;
    }

    public function setCart(?Cart $Cart): static
    {
        $this->Cart = $Cart;

        return $this;
    }
}
