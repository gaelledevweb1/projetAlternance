<?php

namespace App\DataFixtures;

use App\Entity\User;
use App\Entity\Article;
use App\Entity\Address;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        $faker = Faker\Factory::create('fr_FR');
        $users = [];

        for ($i = 0; $i <= 99; $i++) {
            $user = new User();
            $user->setFirstName($faker->firstName());
            $user->setLastName($faker->lastName());
            $user->setPhone($faker->phoneNumber());
            $user->setRole("visiteur");
            $manager->persist($user);
            $users[] = $user;
        }

        $articles = [];
        // $articleStockNumber = random(0, 100);

        for ($i = 0; $i <= 99; $i++) {
            $article = new Article();
            $article->setArticleRef($faker->randomLetter());
            $article->setArticleName($faker->word());
            $article->setArticleImages($faker->imageUrl());
            $article->setArticleThumbNaill($faker->imageUrl());
            $article->setArticleStockQuantity(10);
            $article->setDescription($faker->text());
            $article->setBoughtPrice(39.99);
            $article->setSellPriceHT(59.99);
            $article->setSellPriceTTC(59.99 + 59.99 * 0.196);
            $article->setTVA(0.196);
            $article->setDetails($faker->text());

            $manager->persist($article);
            $articles[] = $article;
        }

        $addresses = [];
        // $articleStockNumber = random(0, 100);

        for ($i = 0; $i <= 99; $i++) {
            $address = new Address();
            $address->setStreetName($faker->streetName());
            $address->setStreetNumber($faker->buildingNumber());
            $address->
            $manager->persist($address);
            $addresses[] = $address;
        }

        $manager->flush();
    }
}
