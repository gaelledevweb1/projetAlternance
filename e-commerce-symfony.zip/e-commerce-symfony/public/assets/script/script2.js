console.log("Connexion Script");
const menuBurgerBtn = document.querySelector("#menuBurgerBtn");
console.log(menuBurgerBtn);
const menuBurger = document.querySelector(".menuBurger");
console.log(menuBurger);
const buttonsSlide = document.querySelector(".buttonsSlide");
console.log(buttonsSlide);

menuBurger.style.transform = "translateY(-110vh)";

menuBurgerBtn.addEventListener("click", () => {
  menuBurgerBtn.classList.toggle("fa-x");
  menuBurgerBtn.classList.toggle("fa-bars");

  menuBurger.style.transform === "translateY(-110vh)"
    ? (menuBurger.style.transform = "translateY(0vh)")
    : (menuBurger.style.transform = "translateY(-110vh)");
});

const imgSlider = document.querySelector("#imgSlider");
console.log(imgSlider);

imgSlider.src = "/assets/media/img/landscape0.jpg";
imgSlider.style.width = "100%";

let i = 1,
  N = 5,
  time = 5;

for (let i = 0; i <= N - 1; i++) {
  buttonsSlide.innerHTML += `
    <span class="spansSlide">a</span>`;
}

const spansSlide = document.querySelectorAll(".spansSlide");
console.log(spansSlide);

spansSlide[0].style.backgroundColor = "goldenrod";

setInterval(() => {
  imgSlider.src = `/assets/media/img/landscape${i % N}.jpg`;

  if (i % N !== 0) {
    spansSlide[i % N].previousElementSibling.style.backgroundColor = "grey";
  } else {
    spansSlide[N - 1].style.backgroundColor = "grey";
  }

  spansSlide[i % N].style.backgroundColor = "goldenrod";
  i++;
}, time * 1000);

// for (let i = 0; i <= N - 1; i++) {
//   spansSlide[i].addEventListener("click", () => {
//     imgSlider.src = `/assets/media/img/landscape${i}.jpg`;
//     spansSlide[i].style.backgroundColor = "white";

//     for (let j = 0; j <= N - 1; j++) {
//       if (j != 1) {
//         spansSlide[j].style.backgroundColor = "grey";
//       }
//     }
//   });
// }
