<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20231108185358 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE adress (id INT AUTO_INCREMENT NOT NULL, user_id INT NOT NULL, order1_id INT NOT NULL, street_number INT NOT NULL, street_name VARCHAR(255) NOT NULL, city VARCHAR(255) NOT NULL, zipcode INT NOT NULL, country VARCHAR(255) NOT NULL, INDEX IDX_5CECC7BEA76ED395 (user_id), UNIQUE INDEX UNIQ_5CECC7BEFEE30A60 (order1_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE article (id INT AUTO_INCREMENT NOT NULL, order1_id INT NOT NULL, article_line_id INT DEFAULT NULL, shopping_basket_id INT DEFAULT NULL, category_id INT DEFAULT NULL, product_name VARCHAR(255) NOT NULL, product_image LONGBLOB DEFAULT NULL, thumbnail_image LONGTEXT NOT NULL COMMENT \'(DC2Type:object)\', description VARCHAR(255) NOT NULL, product_quantity INT DEFAULT NULL, price_ht VARCHAR(255) NOT NULL, price_ttc DOUBLE PRECISION NOT NULL, tva DOUBLE PRECISION NOT NULL, INDEX IDX_23A0E66FEE30A60 (order1_id), INDEX IDX_23A0E66A0A931F5 (article_line_id), INDEX IDX_23A0E66E85C381 (shopping_basket_id), INDEX IDX_23A0E6612469DE2 (category_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE article_line (id INT AUTO_INCREMENT NOT NULL, quantity INT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE category (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE credential (id INT AUTO_INCREMENT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE `order` (id INT AUTO_INCREMENT NOT NULL, article_line_id INT DEFAULT NULL, user_id INT DEFAULT NULL, delivery_information VARCHAR(255) NOT NULL, order_routing VARCHAR(255) NOT NULL, delivering_information VARCHAR(255) NOT NULL, delivering_date DATE NOT NULL, INDEX IDX_F5299398A0A931F5 (article_line_id), UNIQUE INDEX UNIQ_F5299398A76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE paiement (id INT AUTO_INCREMENT NOT NULL, order1_id INT NOT NULL, user_id INT DEFAULT NULL, shopping_basket_id INT DEFAULT NULL, name_of_holder VARCHAR(255) NOT NULL, expire_end DATE NOT NULL, card_number INT NOT NULL, code INT NOT NULL, repeated_payment TINYINT(1) NOT NULL, INDEX IDX_B1DC7A1EFEE30A60 (order1_id), INDEX IDX_B1DC7A1EA76ED395 (user_id), INDEX IDX_B1DC7A1EE85C381 (shopping_basket_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE shopping_basket (id INT AUTO_INCREMENT NOT NULL, quantity INT NOT NULL, price DOUBLE PRECISION NOT NULL, discount DOUBLE PRECISION DEFAULT NULL, promo_code INT DEFAULT NULL, date_added DATE NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, shopping_basket_id INT DEFAULT NULL, credential_id INT DEFAULT NULL, email VARCHAR(180) NOT NULL, roles JSON NOT NULL, password VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_8D93D649E7927C74 (email), UNIQUE INDEX UNIQ_8D93D649E85C381 (shopping_basket_id), UNIQUE INDEX UNIQ_8D93D6492558A7A5 (credential_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE messenger_messages (id BIGINT AUTO_INCREMENT NOT NULL, body LONGTEXT NOT NULL, headers LONGTEXT NOT NULL, queue_name VARCHAR(190) NOT NULL, created_at DATETIME NOT NULL, available_at DATETIME NOT NULL, delivered_at DATETIME DEFAULT NULL, INDEX IDX_75EA56E0FB7336F0 (queue_name), INDEX IDX_75EA56E0E3BD61CE (available_at), INDEX IDX_75EA56E016BA31DB (delivered_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE adress ADD CONSTRAINT FK_5CECC7BEA76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE adress ADD CONSTRAINT FK_5CECC7BEFEE30A60 FOREIGN KEY (order1_id) REFERENCES `order` (id)');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E66FEE30A60 FOREIGN KEY (order1_id) REFERENCES `order` (id)');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E66A0A931F5 FOREIGN KEY (article_line_id) REFERENCES article_line (id)');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E66E85C381 FOREIGN KEY (shopping_basket_id) REFERENCES shopping_basket (id)');
        $this->addSql('ALTER TABLE article ADD CONSTRAINT FK_23A0E6612469DE2 FOREIGN KEY (category_id) REFERENCES category (id)');
        $this->addSql('ALTER TABLE `order` ADD CONSTRAINT FK_F5299398A0A931F5 FOREIGN KEY (article_line_id) REFERENCES article_line (id)');
        $this->addSql('ALTER TABLE `order` ADD CONSTRAINT FK_F5299398A76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE paiement ADD CONSTRAINT FK_B1DC7A1EFEE30A60 FOREIGN KEY (order1_id) REFERENCES `order` (id)');
        $this->addSql('ALTER TABLE paiement ADD CONSTRAINT FK_B1DC7A1EA76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE paiement ADD CONSTRAINT FK_B1DC7A1EE85C381 FOREIGN KEY (shopping_basket_id) REFERENCES shopping_basket (id)');
        $this->addSql('ALTER TABLE user ADD CONSTRAINT FK_8D93D649E85C381 FOREIGN KEY (shopping_basket_id) REFERENCES shopping_basket (id)');
        $this->addSql('ALTER TABLE user ADD CONSTRAINT FK_8D93D6492558A7A5 FOREIGN KEY (credential_id) REFERENCES credential (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE adress DROP FOREIGN KEY FK_5CECC7BEA76ED395');
        $this->addSql('ALTER TABLE adress DROP FOREIGN KEY FK_5CECC7BEFEE30A60');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E66FEE30A60');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E66A0A931F5');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E66E85C381');
        $this->addSql('ALTER TABLE article DROP FOREIGN KEY FK_23A0E6612469DE2');
        $this->addSql('ALTER TABLE `order` DROP FOREIGN KEY FK_F5299398A0A931F5');
        $this->addSql('ALTER TABLE `order` DROP FOREIGN KEY FK_F5299398A76ED395');
        $this->addSql('ALTER TABLE paiement DROP FOREIGN KEY FK_B1DC7A1EFEE30A60');
        $this->addSql('ALTER TABLE paiement DROP FOREIGN KEY FK_B1DC7A1EA76ED395');
        $this->addSql('ALTER TABLE paiement DROP FOREIGN KEY FK_B1DC7A1EE85C381');
        $this->addSql('ALTER TABLE user DROP FOREIGN KEY FK_8D93D649E85C381');
        $this->addSql('ALTER TABLE user DROP FOREIGN KEY FK_8D93D6492558A7A5');
        $this->addSql('DROP TABLE adress');
        $this->addSql('DROP TABLE article');
        $this->addSql('DROP TABLE article_line');
        $this->addSql('DROP TABLE category');
        $this->addSql('DROP TABLE credential');
        $this->addSql('DROP TABLE `order`');
        $this->addSql('DROP TABLE paiement');
        $this->addSql('DROP TABLE shopping_basket');
        $this->addSql('DROP TABLE user');
        $this->addSql('DROP TABLE messenger_messages');
    }
}
