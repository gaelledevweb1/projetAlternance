<?php

namespace App\Entity;

use App\Repository\PaiementRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PaiementRepository::class)]
class Paiement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nameOfHolder = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $ExpireEnd = null;

    #[ORM\Column]
    private ?int $CardNumber = null;

    #[ORM\Column]
    private ?int $code = null;

    #[ORM\Column]
    private ?bool $repeatedPayment = null;

    #[ORM\ManyToOne(inversedBy: 'paiement')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Order $order1 = null;

    #[ORM\ManyToOne(inversedBy: 'paiement')]
    private ?User $user = null;

    #[ORM\ManyToOne(inversedBy: 'paiements')]
    private ?ShoppingBasket $shoppingBasket = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNameOfHolder(): ?string
    {
        return $this->nameOfHolder;
    }

    public function setNameOfHolder(string $nameOfHolder): static
    {
        $this->nameOfHolder = $nameOfHolder;

        return $this;
    }

    public function getExpireEnd(): ?\DateTimeInterface
    {
        return $this->ExpireEnd;
    }

    public function setExpireEnd(\DateTimeInterface $ExpireEnd): static
    {
        $this->ExpireEnd = $ExpireEnd;

        return $this;
    }

    public function getCardNumber(): ?int
    {
        return $this->CardNumber;
    }

    public function setCardNumber(int $CardNumber): static
    {
        $this->CardNumber = $CardNumber;

        return $this;
    }

    public function getCode(): ?int
    {
        return $this->code;
    }

    public function setCode(int $code): static
    {
        $this->code = $code;

        return $this;
    }

    public function isRepeatedPayment(): ?bool
    {
        return $this->repeatedPayment;
    }

    public function setRepeatedPayment(bool $repeatedPayment): static
    {
        $this->repeatedPayment = $repeatedPayment;

        return $this;
    }

    public function getOrder1(): ?Order
    {
        return $this->order1;
    }

    public function setOrder1(?Order $order1): static
    {
        $this->order1 = $order1;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): static
    {
        $this->user = $user;

        return $this;
    }

    public function getShoppingBasket(): ?ShoppingBasket
    {
        return $this->shoppingBasket;
    }

    public function setShoppingBasket(?ShoppingBasket $shoppingBasket): static
    {
        $this->shoppingBasket = $shoppingBasket;

        return $this;
    }
}
