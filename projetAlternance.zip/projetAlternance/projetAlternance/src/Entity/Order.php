<?php

namespace App\Entity;

use App\Repository\OrderRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: OrderRepository::class)]
#[ORM\Table(name: '`order`')]
class Order
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $deliveryInformation = null;

    #[ORM\Column(length: 255)]
    private ?string $orderRouting = null;

    #[ORM\Column(length: 255)]
    private ?string $deliveringInformation = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $deliveringDate = null;

    #[ORM\OneToOne(mappedBy: 'order1', cascade: ['persist', 'remove'])]
    private ?Adress $adress = null;

    #[ORM\OneToMany(mappedBy: 'order1', targetEntity: Paiement::class)]
    private Collection $paiement;

    #[ORM\OneToMany(mappedBy: 'order1', targetEntity: Article::class, orphanRemoval: true)]
    private Collection $article;

    #[ORM\ManyToOne(inversedBy: 'orders')]
    private ?ArticleLine $articleLine = null;

    #[ORM\OneToOne(cascade: ['persist', 'remove'])]
    private ?User $user = null;

    public function __construct()
    {
        $this->paiement = new ArrayCollection();
        $this->article = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDeliveryInformation(): ?string
    {
        return $this->deliveryInformation;
    }

    public function setDeliveryInformation(string $deliveryInformation): static
    {
        $this->deliveryInformation = $deliveryInformation;

        return $this;
    }

    public function getOrderRouting(): ?string
    {
        return $this->orderRouting;
    }

    public function setOrderRouting(string $orderRouting): static
    {
        $this->orderRouting = $orderRouting;

        return $this;
    }

    public function getDeliveringInformation(): ?string
    {
        return $this->deliveringInformation;
    }

    public function setDeliveringInformation(string $deliveringInformation): static
    {
        $this->deliveringInformation = $deliveringInformation;

        return $this;
    }

    public function getDeliveringDate(): ?\DateTimeInterface
    {
        return $this->deliveringDate;
    }

    public function setDeliveringDate(\DateTimeInterface $deliveringDate): static
    {
        $this->deliveringDate = $deliveringDate;

        return $this;
    }

    public function getAdress(): ?Adress
    {
        return $this->adress;
    }

    public function setAdress(Adress $adress): static
    {
        // set the owning side of the relation if necessary
        if ($adress->getOrder1() !== $this) {
            $adress->setOrder1($this);
        }

        $this->adress = $adress;

        return $this;
    }

    /**
     * @return Collection<int, Paiement>
     */
    public function getPaiement(): Collection
    {
        return $this->paiement;
    }

    public function addPaiement(Paiement $paiement): static
    {
        if (!$this->paiement->contains($paiement)) {
            $this->paiement->add($paiement);
            $paiement->setOrder1($this);
        }

        return $this;
    }

    public function removePaiement(Paiement $paiement): static
    {
        if ($this->paiement->removeElement($paiement)) {
            // set the owning side to null (unless already changed)
            if ($paiement->getOrder1() === $this) {
                $paiement->setOrder1(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Article>
     */
    public function getArticle(): Collection
    {
        return $this->article;
    }

    public function addArticle(Article $article): static
    {
        if (!$this->article->contains($article)) {
            $this->article->add($article);
            $article->setOrder1($this);
        }

        return $this;
    }

    public function removeArticle(Article $article): static
    {
        if ($this->article->removeElement($article)) {
            // set the owning side to null (unless already changed)
            if ($article->getOrder1() === $this) {
                $article->setOrder1(null);
            }
        }

        return $this;
    }

    public function getArticleLine(): ?ArticleLine
    {
        return $this->articleLine;
    }

    public function setArticleLine(?ArticleLine $articleLine): static
    {
        $this->articleLine = $articleLine;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): static
    {
        $this->user = $user;

        return $this;
    }
}
