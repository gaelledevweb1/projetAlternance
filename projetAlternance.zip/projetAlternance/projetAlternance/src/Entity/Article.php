<?php

namespace App\Entity;

use App\Repository\ArticleRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ArticleRepository::class)]
class Article
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $productName = null;

    #[ORM\Column(type: Types::BLOB, nullable: true)]
    private $productImage = null;

    #[ORM\Column(type: Types::OBJECT)]
    private ?object $thumbnailImage = null;

    #[ORM\Column(length: 255)]
    private ?string $description = null;

    #[ORM\Column(nullable: true)]
    private ?int $productQuantity = null;

    #[ORM\Column(type: Types::ASCII_STRING)]
    private $price_HT = null;

    #[ORM\Column]
    private ?float $price_TTC = null;

    #[ORM\Column]
    private ?float $TVA = null;

    #[ORM\ManyToOne(inversedBy: 'article')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Order $order1 = null;

    #[ORM\ManyToOne(inversedBy: 'articles')]
    private ?ArticleLine $articleLine = null;

    #[ORM\ManyToOne(inversedBy: 'articles')]
    private ?ShoppingBasket $shoppingBasket = null;

    #[ORM\ManyToOne(inversedBy: 'articles')]
    private ?Category $category = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getProductName(): ?string
    {
        return $this->productName;
    }

    public function setProductName(string $productName): static
    {
        $this->productName = $productName;

        return $this;
    }

    public function getProductImage()
    {
        return $this->productImage;
    }

    public function setProductImage($productImage): static
    {
        $this->productImage = $productImage;

        return $this;
    }

    public function getThumbnailImage(): ?object
    {
        return $this->thumbnailImage;
    }

    public function setThumbnailImage(object $thumbnailImage): static
    {
        $this->thumbnailImage = $thumbnailImage;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getProductQuantity(): ?int
    {
        return $this->productQuantity;
    }

    public function setProductQuantity(?int $productQuantity): static
    {
        $this->productQuantity = $productQuantity;

        return $this;
    }

    public function getPriceHT()
    {
        return $this->price_HT;
    }

    public function setPriceHT($price_HT): static
    {
        $this->price_HT = $price_HT;

        return $this;
    }

    public function getPriceTTC(): ?float
    {
        return $this->price_TTC;
    }

    public function setPriceTTC(float $price_TTC): static
    {
        $this->price_TTC = $price_TTC;

        return $this;
    }

    public function getTVA(): ?float
    {
        return $this->TVA;
    }

    public function setTVA(float $TVA): static
    {
        $this->TVA = $TVA;

        return $this;
    }

    public function getOrder1(): ?Order
    {
        return $this->order1;
    }

    public function setOrder1(?Order $order1): static
    {
        $this->order1 = $order1;

        return $this;
    }

    public function getArticleLine(): ?ArticleLine
    {
        return $this->articleLine;
    }

    public function setArticleLine(?ArticleLine $articleLine): static
    {
        $this->articleLine = $articleLine;

        return $this;
    }

    public function getShoppingBasket(): ?ShoppingBasket
    {
        return $this->shoppingBasket;
    }

    public function setShoppingBasket(?ShoppingBasket $shoppingBasket): static
    {
        $this->shoppingBasket = $shoppingBasket;

        return $this;
    }

    public function getCategory(): ?Category
    {
        return $this->category;
    }

    public function setCategory(?Category $category): static
    {
        $this->category = $category;

        return $this;
    }
}
