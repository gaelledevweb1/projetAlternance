<?php

namespace App\Repository;

use App\Entity\ArticleLine;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<ArticleLine>
 *
 * @method ArticleLine|null find($id, $lockMode = null, $lockVersion = null)
 * @method ArticleLine|null findOneBy(array $criteria, array $orderBy = null)
 * @method ArticleLine[]    findAll()
 * @method ArticleLine[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ArticleLineRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, ArticleLine::class);
    }

//    /**
//     * @return ArticleLine[] Returns an array of ArticleLine objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('a')
//            ->andWhere('a.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('a.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?ArticleLine
//    {
//        return $this->createQueryBuilder('a')
//            ->andWhere('a.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}
