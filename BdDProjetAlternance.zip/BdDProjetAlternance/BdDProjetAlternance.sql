-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3300
-- Généré le : jeu. 09 nov. 2023 à 14:08
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bddonnees`
--

-- --------------------------------------------------------

--
-- Structure de la table `address`
--

CREATE TABLE `address` (
  `IDAddress` varchar(255) NOT NULL,
  `IDUSer` varchar(255) NOT NULL,
  `StreetName` varchar(255) NOT NULL,
  `StreetNumber` int(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `ZIPCode` varchar(255) NOT NULL,
  `Country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `IDArticle` varchar(255) NOT NULL,
  `IDCategory` varchar(255) NOT NULL,
  `ArticleRef` varchar(255) NOT NULL,
  `ArticleName` varchar(255) NOT NULL,
  `ArticleImages` varchar(255) NOT NULL,
  `ArticleThumbnails` varchar(255) NOT NULL,
  `ArticleStockQuantity` varchar(255) NOT NULL,
  `ArticleDescription` text NOT NULL,
  `BoughtPrice` float NOT NULL,
  `SellPriceHT` float NOT NULL,
  `SellPriceTTC` float NOT NULL,
  `TVA` float NOT NULL,
  `Details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `IDCart` varchar(255) NOT NULL,
  `IDUser` varchar(255) NOT NULL,
  `IDArticle` varchar(255) NOT NULL,
  `ArticleQuantify` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `IDCategory` varchar(255) NOT NULL,
  `NameCategory` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `credentials`
--

CREATE TABLE `credentials` (
  `IDCredentials` varchar(255) NOT NULL,
  `IDUser` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `UserEmail` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `order`
--

CREATE TABLE `order` (
  `IDOrder` varchar(255) NOT NULL,
  `IDAddress` varchar(255) NOT NULL,
  `IDUser` varchar(255) NOT NULL,
  `IDCart` varchar(255) NOT NULL,
  `OrderDate` datetime NOT NULL,
  `Paid` tinyint(1) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `Delivered` tinyint(1) NOT NULL,
  `DeliveryDate` datetime NOT NULL,
  `DeliveryInfo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE `paiement` (
  `IDPaiement` varchar(255) NOT NULL,
  `IDCart` varchar(255) NOT NULL,
  `IDUser` varchar(255) NOT NULL,
  `IDOrder` varchar(255) NOT NULL,
  `BankName` varchar(255) NOT NULL,
  `CardName` varchar(255) NOT NULL,
  `CardNumber` varchar(255) NOT NULL,
  `CardNetwork` varchar(255) NOT NULL,
  `CardHolderName` varchar(255) NOT NULL,
  `ExpirationDate` date NOT NULL,
  `CVCCode` varchar(255) NOT NULL,
  `SecurityCard` varchar(255) NOT NULL,
  `Currency` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `IDUser` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `PhoneNumber` varchar(255) NOT NULL,
  `Role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`IDAddress`),
  ADD KEY `IDUSer` (`IDUSer`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`IDArticle`),
  ADD KEY `IDCategory` (`IDCategory`);

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`IDCart`),
  ADD KEY `IDArticle` (`IDArticle`),
  ADD KEY `IDUser` (`IDUser`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`IDCategory`);

--
-- Index pour la table `credentials`
--
ALTER TABLE `credentials`
  ADD PRIMARY KEY (`IDCredentials`),
  ADD KEY `IDUser` (`IDUser`);

--
-- Index pour la table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`IDOrder`),
  ADD KEY `IDAddress` (`IDAddress`),
  ADD KEY `IDCart` (`IDCart`),
  ADD KEY `IDUser` (`IDUser`);

--
-- Index pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`IDPaiement`),
  ADD KEY `IDCart` (`IDCart`),
  ADD KEY `IDOrder` (`IDOrder`),
  ADD KEY `IDUser` (`IDUser`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`IDUser`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`IDUSer`) REFERENCES `user` (`IDUser`);

--
-- Contraintes pour la table `article`
--
ALTER TABLE `article`
  ADD CONSTRAINT `article_ibfk_1` FOREIGN KEY (`IDCategory`) REFERENCES `category` (`IDCategory`);

--
-- Contraintes pour la table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`IDArticle`) REFERENCES `article` (`IDArticle`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`IDUser`) REFERENCES `user` (`IDUser`);

--
-- Contraintes pour la table `credentials`
--
ALTER TABLE `credentials`
  ADD CONSTRAINT `credentials_ibfk_1` FOREIGN KEY (`IDUser`) REFERENCES `user` (`IDUser`);

--
-- Contraintes pour la table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`IDAddress`) REFERENCES `address` (`IDAddress`),
  ADD CONSTRAINT `order_ibfk_2` FOREIGN KEY (`IDCart`) REFERENCES `cart` (`IDCart`),
  ADD CONSTRAINT `order_ibfk_3` FOREIGN KEY (`IDUser`) REFERENCES `user` (`IDUser`);

--
-- Contraintes pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD CONSTRAINT `paiement_ibfk_1` FOREIGN KEY (`IDCart`) REFERENCES `cart` (`IDCart`),
  ADD CONSTRAINT `paiement_ibfk_2` FOREIGN KEY (`IDOrder`) REFERENCES `order` (`IDOrder`),
  ADD CONSTRAINT `paiement_ibfk_3` FOREIGN KEY (`IDUser`) REFERENCES `user` (`IDUser`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
